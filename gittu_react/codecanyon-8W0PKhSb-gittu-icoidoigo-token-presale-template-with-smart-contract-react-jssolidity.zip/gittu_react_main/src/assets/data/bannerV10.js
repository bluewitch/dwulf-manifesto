import TitleImg from "../images/banner/lock.png";

const Data = {
  title: "Unlock",
  titleImg: TitleImg,
  titleExtra: "new investment",
  titleLine: "opportunities",
  subtitle: "Invest in cutting-edge blockchain projects and be part of",
  subtitleExtra: "the future of web3.0 finance",
};

export default Data;
