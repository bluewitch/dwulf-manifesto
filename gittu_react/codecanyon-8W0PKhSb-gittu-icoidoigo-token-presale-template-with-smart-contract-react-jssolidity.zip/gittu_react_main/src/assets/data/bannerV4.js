const Data = {
  title: "WEB3.0 TOKEN",
  subtitle:
    "Buy tokens now and reap the benefits of the blockchain revolution!",
};

export default Data;
