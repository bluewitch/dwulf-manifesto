import Img1 from "../images/partners/1.png";
import Img2 from "../images/partners/2.png";
import Img3 from "../images/partners/3.png";
import Img4 from "../images/partners/4.png";
import Img5 from "../images/partners/5.png";
import Img6 from "../images/partners/6.png";
import Img7 from "../images/partners/7.png";
import Img8 from "../images/partners/8.png";

const data = [
    { icon: Img1 },
    { icon: Img2 },
    { icon: Img3 },
    { icon: Img4 },
    { icon: Img5 },
    { icon: Img6 },
    { icon: Img7 },
    { icon: Img8 },
    { icon: Img1 },
    { icon: Img2 },
    { icon: Img3 },
    { icon: Img4 },
    { icon: Img5 },
    { icon: Img6 },
    { icon: Img7 },
    { icon: Img8 },
];

export default data;