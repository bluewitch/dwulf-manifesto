const Data = {
  title: "Unified Decentralized",
  title2: "Platform",
  subtitle:
    "Buy tokens now and reap the benefits of the blockchain revolution!",
};

export default Data;
