const Data = {
  title: "BUILD",
  title2: "WEB3.0",
  title3: "EARTH",
  subtitle:
    "Buy tokens now and reap the benefits of the blockchain revolution. Benefit and influence the development of a project made for a massive profitable audience",
};

export default Data;
