const Data = {
  status: "New roadmap added for Phase 4 - 2024",
  title: "Unified Web",
  title2: "3.0 TRADE",
  subtitle:
    "Buy tokens now and reap the benefits of the blockchain revolution. Benefit and influence the development of a project",
};

export default Data;
