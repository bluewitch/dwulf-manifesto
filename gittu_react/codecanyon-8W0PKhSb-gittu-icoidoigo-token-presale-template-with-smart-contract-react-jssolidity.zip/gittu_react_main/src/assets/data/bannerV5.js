const Data = {
  title: "Making Something Great!",
  subtitle:
    "Buy tokens now and reap the benefits of the blockchain revolution!",
  presaleStatus: "Pre-Sale Ends in",
};

export default Data;
