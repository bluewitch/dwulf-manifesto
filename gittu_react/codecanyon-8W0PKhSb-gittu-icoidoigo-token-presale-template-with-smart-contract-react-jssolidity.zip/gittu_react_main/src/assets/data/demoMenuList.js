const Data = [
  {
    title: "Demo One",
    url: "/",
  },
  {
    title: "Demo Two",
    url: "/home-two",
  },
  {
    title: "Demo Three",
    url: "/home-three",
  },
  {
    title: "Demo Four",
    url: "/home-four",
  },
  {
    title: "Demo Five",
    url: "/home-five",
  },
  {
    title: "Demo Six",
    url: "/home-six",
  },
  {
    title: "Demo Seven",
    url: "/home-seven",
  },
  {
    title: "Demo Eight",
    url: "/home-eight",
  },
  {
    title: "Demo Nine",
    url: "/home-nine",
  },
  {
    title: "Demo Ten",
    url: "/home-ten",
  },
];

export default Data;
