const Data = {
  title: "Discover the next",
  titleExtra: "big in Crypto",
  subtitle:
    "Invest in cutting-edge blockchain projects and be part of the future of web3.0 finance",
};

export default Data;
