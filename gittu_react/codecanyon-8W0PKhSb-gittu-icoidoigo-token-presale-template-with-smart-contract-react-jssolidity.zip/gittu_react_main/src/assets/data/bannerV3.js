const Data = {
  presaleStatus: "Pre-Sale Ends in",
  title: "BUILD",
  title2: "WEB3.0",
  title3: "EARTH",
  subtitle:
    "Buy tokens now and reap the benefits of the blockchain revolution!",
};

export default Data;
